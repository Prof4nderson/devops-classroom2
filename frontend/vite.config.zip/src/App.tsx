import React, { useState, useEffect } from 'react';
import { useAuth } from './contexts/AuthContext';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import ChatRoom from './components/ChatRoom';
import { Aula, Usuario } from './types';
import {
  LayoutDashboard,
  Users,
  BookOpen,
  Calendar,
  MessageSquare,
  LogOut,
  Terminal,
  GraduationCap,
  Plus,
  Play,
  Square,
  CheckCircle,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

type Page = 'dashboard' | 'cursos' | 'alunos' | 'aula';

function App() {
  const { user, token, logout, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [aulas, setAulas] = useState<Aula[]>([]);
  const [selectedAula, setSelectedAula] = useState<Aula | null>(null);
  const [cursos, setCursos] = useState<any[]>([]);
  const [alunos, setAlunos] = useState<Usuario[]>([]);
  const API_BASE_URL = 'http://localhost:8080';

  useEffect(() => {
    // Só carrega os dados se o usuário E o token já estiverem prontos no contexto
    if (user && token) {
      loadData();
    }
  }, [user, token]);

  const loadData = async () => {
    // Trava de segurança adicional
    if (!token) return;

    try {
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };

      const aulasResp = await fetch('/api/aulas/em-andamento', { headers });
      if (aulasResp.ok) {
        setAulas(await aulasResp.json());
      } else {
        const errText = await aulasResp.text(); // <--- Pega a mensagem do Spring
        console.error('Detalhe do Erro 400 Aulas:', errText);
      }
      const cursosResp = await fetch('/api/cursos', { headers });
      if (cursosResp.ok) {
        setCursos(await cursosResp.json());
      } else {
        console.error('Erro /api/cursos:', cursosResp.status);
      }

      const alunosResp = await fetch('/api/auth/users', { headers });
      if (alunosResp.ok) {
        const users = await alunosResp.json();
        setAlunos(users.filter((u: any) => u.tipo === 'ALUNO'));
      } else {
        console.error('Erro /api/auth/users:', alunosResp.status);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  };

  const iniciarAula = async (aulaId: number) => {
    try {
      const resp = await fetch(`/api/aulas/${aulaId}/iniciar`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (resp.ok) {
        const aula = await resp.json();
        setSelectedAula(aula);
        setCurrentPage('aula');
        toast.success('Aula iniciada!');
      }
    } catch (error) {
      toast.error('Erro ao iniciar aula');
    }
  };

  const finalizarAula = async () => {
    if (!selectedAula) return;
    try {
      await fetch(`/api/aulas/${selectedAula.id}/finalizar`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      setSelectedAula(null);
      setCurrentPage('dashboard');
      loadData();
      toast.success('Aula finalizada!');
    } catch (error) {
      toast.error('Erro ao finalizar aula');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 neon animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  if (currentPage === 'aula' && selectedAula) {
    return <ChatRoom aula={selectedAula} user={user} />;
  }

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <div className="w-64 glass-bar border-r flex flex-col">
        <div className="p-4 border-b divider">
          <div className="flex items-center gap-2">
            <Terminal className="w-6 h-6 neon" />
            <span className="font-bold title-glow">DevOps Classroom</span>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1.5">
          <button
            onClick={() => setCurrentPage('dashboard')}
            className={`nav-item ${currentPage === 'dashboard' ? 'nav-item-active' : ''}`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Dashboard
          </button>

          <button
            onClick={() => setCurrentPage('cursos')}
            className={`nav-item ${currentPage === 'cursos' ? 'nav-item-active' : ''}`}
          >
            <BookOpen className="w-4 h-4" />
            Cursos
          </button>

          <button
            onClick={() => setCurrentPage('alunos')}
            className={`nav-item ${currentPage === 'alunos' ? 'nav-item-active' : ''}`}
          >
            <Users className="w-4 h-4" />
            Alunos
          </button>
        </nav>

        <div className="p-4 border-t divider">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl glass flex items-center justify-center">
              <GraduationCap className="w-4 h-4 neon" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">{user.nome}</p>
              <p className="text-xs txt-faint">{user.tipo}</p>
            </div>
          </div>
          <button onClick={logout} className="btn-ghost w-full">
            <LogOut className="w-4 h-4" />
            Sair
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <header className="p-6 border-b divider glass-bar">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold title-glow">
              {currentPage === 'dashboard' && 'Dashboard'}
              {currentPage === 'cursos' && 'Cursos'}
              {currentPage === 'alunos' && 'Alunos'}
            </h1>
            <span className="text-sm txt-dim">
              {new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
          </div>
        </header>

        <main className="p-6">
          {currentPage === 'dashboard' && (
            <div className="space-y-6">
              {/* Stats */}
              <div className="grid grid-cols-4 gap-4">
                <div className="card">
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-8 h-8 neon" />
                    <div>
                      <p className="text-2xl font-bold">{cursos.length}</p>
                      <p className="text-sm txt-dim">Cursos</p>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="flex items-center gap-3">
                    <Users className="w-8 h-8 neon-lime" />
                    <div>
                      <p className="text-2xl font-bold">{alunos.length}</p>
                      <p className="text-sm txt-dim">Alunos</p>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-8 h-8 neon-violet" />
                    <div>
                      <p className="text-2xl font-bold">{aulas.length}</p>
                      <p className="text-sm txt-dim">Aulas Ativas</p>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-8 h-8 neon-amber" />
                    <div>
                      <p className="text-2xl font-bold">0</p>
                      <p className="text-sm txt-dim">Quizzes Hoje</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Aulas em andamento */}
              <div>
                <h2 className="text-lg font-semibold mb-4 title-glow">Aulas em Andamento</h2>
                <div className="space-y-3">
                  {aulas.map((aula) => (
                    <div key={aula.id} className="card flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={
                            aula.status === 'EM_ANDAMENTO'
                              ? 'dot-live animate-pulse'
                              : 'w-2 h-2 rounded-full bg-amber-300'
                          }
                        />
                        <div>
                          <p className="font-medium">{aula.titulo}</p>
                          <p className="text-sm txt-dim">{aula.curso?.nome} • {aula.duracao}</p>
                        </div>
                      </div>
                      <button onClick={() => iniciarAula(aula.id)} className="btn-primary">
                        <Play className="w-4 h-4" />
                        Entrar
                      </button>
                    </div>
                  ))}
                  {aulas.length === 0 && (
                    <p className="txt-faint text-center py-8">Nenhuma aula em andamento</p>
                  )}
                </div>
              </div>

              {/* Ação rápida para professores */}
              {user.tipo === 'PROFESSOR' && (
                <div className="card">
                  <h3 className="text-xs font-semibold txt-dim uppercase tracking-wider mb-4">Ações Rápidas</h3>
                  <div className="flex gap-3">
                    <button onClick={() => setCurrentPage('cursos')} className="btn-primary">
                      <Plus className="w-4 h-4" />
                      Novo Curso
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {currentPage === 'cursos' && (
            <div className="space-y-6">
              {user.tipo === 'PROFESSOR' && (
                <div className="card">
                  <h3 className="text-lg font-semibold mb-4 title-glow">Criar Novo Curso</h3>
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = e.target as HTMLFormElement;
                      const formData = new FormData(form);
                      try {
                        const resp = await fetch('/api/cursos', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                            Authorization: `Bearer ${token}`,
                          },
                          body: JSON.stringify({
                            nome: formData.get('nome'),
                            descricao: formData.get('descricao'),
                            codigo: formData.get('codigo'),
                          }),
                        });
                        if (resp.ok) {
                          toast.success('Curso criado!');
                          loadData();
                          (form as HTMLFormElement).reset();
                        }
                      } catch (error) {
                        toast.error('Erro ao criar curso');
                      }
                    }}
                    className="grid grid-cols-3 gap-4"
                  >
                    <input name="nome" className="input-field" placeholder="Nome do curso" required />
                    <input name="codigo" className="input-field" placeholder="Código" required />
                    <input name="descricao" className="input-field" placeholder="Descrição" />
                    <button type="submit" className="btn-primary col-span-3">
                      <Plus className="w-4 h-4" />
                      Criar Curso
                    </button>
                  </form>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                {cursos.map((curso) => (
                  <div key={curso.id} className="card">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold">{curso.nome}</h3>
                      <span className="badge-neon">{curso.codigo}</span>
                    </div>
                    <p className="text-sm txt-dim mb-3">{curso.descricao || 'Sem descrição'}</p>
                    <p className="text-xs txt-faint">Professor: {curso.professor?.nome}</p>
                  </div>
                ))}
                {cursos.length === 0 && (
                  <p className="txt-faint text-center py-8 col-span-2">Nenhum curso cadastrado</p>
                )}
              </div>
            </div>
          )}

          {currentPage === 'alunos' && (
            <div className="space-y-4">
              <div className="card">
                <div className="flex items-center gap-3 mb-4">
                  <h3 className="text-lg font-semibold title-glow">Alunos Cadastrados</h3>
                  <span className="badge-neon">{alunos.length}</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b divider">
                        <th className="text-left py-3 px-4 txt-dim font-medium">Nome</th>
                        <th className="text-left py-3 px-4 txt-dim font-medium">Login</th>
                        <th className="text-left py-3 px-4 txt-dim font-medium">Email</th>
                        <th className="text-left py-3 px-4 txt-dim font-medium">Telefone</th>
                        <th className="text-left py-3 px-4 txt-dim font-medium">Instituição</th>
                      </tr>
                    </thead>
                    <tbody>
                      {alunos.map((aluno) => (
                        <tr key={aluno.id} className="border-b divider table-row-glass">
                          <td className="py-3 px-4">{aluno.nome}</td>
                          <td className="py-3 px-4 txt-dim">{aluno.login}</td>
                          <td className="py-3 px-4 txt-dim">{aluno.email}</td>
                          <td className="py-3 px-4 txt-dim">{aluno.telefone}</td>
                          <td className="py-3 px-4 txt-dim">{aluno.instituicao}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {alunos.length === 0 && (
                    <p className="txt-faint text-center py-8">Nenhum aluno cadastrado</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
