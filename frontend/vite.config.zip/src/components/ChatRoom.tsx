import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatWebSocket } from '../services/websocket';
import { ChatMessage, PresenceUpdate, Aula, Usuario } from '../types';
import { Send, Image, Code, Bot, Users, Clock, Trophy } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../services/api';

interface ChatRoomProps {
  aula: Aula;
  user: Usuario;
}

const ChatRoom: React.FC<ChatRoomProps> = ({ aula, user }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [presentes, setPresentes] = useState<Record<number, string>>({});
  const [showCodeEditor, setShowCodeEditor] = useState(false);
  const [codeText, setCodeText] = useState('');
  const [codeLanguage, setCodeLanguage] = useState('bash');
  const [activeQuiz, setActiveQuiz] = useState<any>(null);
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [quizForm, setQuizForm] = useState({ pergunta: '', opcoes: ['', '', '', ''], respostaCorreta: '', tempoLimite: 30 });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wsRef = useRef<ChatWebSocket | null>(null);

  // 1. Carregar mensagens anteriores
  // 2. Conectar WebSocket com controle anti-duplicação
  useEffect(() => {
    const handlePresence = (data: PresenceUpdate) => {
      setPresentes(data.presentes || {});
    };

    const handleQuiz = (data: any) => {
      if (data.tipo === 'QUIZ_CREATED') {
        setActiveQuiz(data);
        setShowQuizModal(true);
        toast('Novo quiz do professor!', { icon: '🎯' });
      }
    };

    const ws = new ChatWebSocket(
      aula.id,
      (newMsg) => setMessages((prev) => {
        if (prev.some((m) => m.id === newMsg.id || (m.conteudo === newMsg.conteudo && m.usuarioId === newMsg.usuarioId))) {
          return prev;
        }
        return [...prev, newMsg];
      }),
      handlePresence,
      handleQuiz
    );

    wsRef.current = ws;
    ws.connect();

    return () => {
      ws.leave();
    };
  }, [aula.id]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = useCallback(() => {
    if (!inputText.trim()) return;

    const textoEnviar = inputText;
    setInputText('');

    const tempId = Date.now();

    wsRef.current?.sendMessage(textoEnviar, 'TEXT');
  }, [inputText]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    const isImage = file.type.startsWith('image/');
    const endpoint = isImage ? '/api/uploads/image' : '/api/uploads/file';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        const tipo = isImage ? (inputText.includes('```') ? 'CODE' : 'IMAGE') : 'FILE';
        wsRef.current?.sendMessage(
          inputText || file.name,
          tipo,
          data.url,
          data.nomeArquivo,
          data.mimeType
        );
      }
    } catch (error) {
      toast.error('Erro ao enviar arquivo');
    }

    e.target.value = '';
  };

  const sendCode = () => {
    if (!codeText.trim()) return;
    const content = `\`\`\`${codeLanguage}\n${codeText}\n\`\`\``;
    wsRef.current?.sendMessage(content, 'CODE');
    setCodeText('');
    setShowCodeEditor(false);
  };

  const sendScreenshot = () => {
    if (fileInputRef.current) {
      fileInputRef.current.accept = 'image/*';
      fileInputRef.current.click();
    }
  };

  const createQuiz = async () => {
    try {
      const response = await fetch('/api/quizzes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          aulaId: aula.id,
          pergunta: quizForm.pergunta,
          opcoes: quizForm.opcoes.filter((o) => o.trim()),
          respostaCorreta: quizForm.respostaCorreta,
          tempoLimiteSegundos: quizForm.tempoLimite,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        wsRef.current?.createQuiz(quizForm.pergunta, quizForm.opcoes.filter((o) => o.trim()), data.id);
        setShowQuizModal(false);
        setQuizForm({ pergunta: '', opcoes: ['', '', '', ''], respostaCorreta: '', tempoLimite: 30 });
        toast.success('Quiz criado!');
      }
    } catch (error) {
      toast.error('Erro ao criar quiz');
    }
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar - Presentes */}
      <div className="w-64 glass-bar border-r flex flex-col">
        <div className="p-4 border-b divider">
          <h3 className="text-xs font-semibold txt-dim uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 neon" />
            Presentes ({Object.keys(presentes).length})
          </h3>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {Object.entries(presentes).map(([id, nome]) => (
            <div
              key={id}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border border-transparent hover:border-white/10 hover:bg-white/5 transition-colors"
            >
              <div className="dot-live animate-pulse" />
              <span className="text-sm txt-dim truncate">{nome}</span>
              {parseInt(id) === user.id && (
                <span className="text-xs neon ml-auto">(você)</span>
              )}
            </div>
          ))}
          {Object.keys(presentes).length === 0 && (
            <p className="text-sm txt-faint text-center py-4">Ninguém presente ainda</p>
          )}
        </div>
      </div>

      {/* Chat Principal */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b divider glass-bar flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold title-glow">{aula.titulo}</h2>
            <p className="text-sm txt-dim">{aula.curso?.nome} • {aula.status}</p>
          </div>
          <div className="flex items-center gap-2 badge-neon">
            <Clock className="w-3.5 h-3.5" />
            <span>{aula.duracao}</span>
          </div>
        </div>

        {/* Quiz Modal */}
        {showQuizModal && activeQuiz && (
          <div className="mx-4 mt-4 p-4 quiz-panel">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-5 h-5 neon-violet" />
              <span className="text-sm font-semibold neon-violet">Quiz - {activeQuiz.professorNome}</span>
            </div>
            <p className="mb-3">{activeQuiz.pergunta}</p>
            <div className="space-y-2">
              {(activeQuiz.opcoes || []).map((op: string, i: number) => (
                <button
                  key={i}
                  onClick={() => wsRef.current?.respondQuiz(activeQuiz.quizId, op)}
                  className="quiz-option"
                >
                  {op}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, idx) => {
            // Descobre o ID do usuário de forma segura (seja direto ou dentro do objeto usuario)
            const autorId = msg.usuarioId || msg.usuario?.id;
            const autorNome = msg.usuarioNome || msg.usuario?.nome || 'Usuário';
            const autorTipo = msg.usuarioTipo || msg.usuario?.tipo;
            const ehMinha = autorId === user.id;

            return (
              <div
                key={msg.id || idx}
                className={`flex ${ehMinha ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                    autorTipo === 'AI'
                      ? 'bubble-ai'
                      : ehMinha
                      ? 'bubble-mine'
                      : 'bubble-other'
                  }`}
                >
                  {!ehMinha && (
                    <p className={`text-xs font-medium mb-1 ${autorTipo === 'AI' ? 'neon-violet' : 'neon'}`}>
                      {autorTipo === 'AI' ? <Bot className="w-3 h-3 inline mr-1" /> : null}
                      {autorNome}
                    </p>
                  )}

                  {/* O restante do conteúdo da mensagem continua igual */}
                  <p className="text-sm whitespace-pre-wrap">{msg.conteudo}</p>

                  <p className={`text-xs mt-1 ${ehMinha ? 'opacity-70' : 'txt-faint'}`}>
                    {msg.criadoEm
                      ? new Date(msg.criadoEm).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
                      : ''}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 border-t divider glass-bar">
          {/* Code Editor */}
          {showCodeEditor && (
            <div className="mb-3 p-3 glass rounded-2xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm txt-dim">Snippet de Código</span>
                <select
                  value={codeLanguage}
                  onChange={(e) => setCodeLanguage(e.target.value)}
                  className="input-field w-auto text-xs py-1"
                >
                  <option value="bash">Bash</option>
                  <option value="docker">Dockerfile</option>
                  <option value="yaml">YAML</option>
                  <option value="python">Python</option>
                  <option value="java">Java</option>
                  <option value="javascript">JavaScript</option>
                  <option value="terraform">Terraform</option>
                  <option value="text">Texto</option>
                </select>
              </div>
              <textarea
                className="code-area"
                value={codeText}
                onChange={(e) => setCodeText(e.target.value)}
                placeholder="Cole ou digite seu código..."
              />
              <div className="flex justify-end gap-2 mt-2">
                <button onClick={() => setShowCodeEditor(false)} className="btn-secondary text-sm">
                  Cancelar
                </button>
                <button onClick={sendCode} className="btn-primary text-sm">
                  Enviar Código
                </button>
              </div>
            </div>
          )}

          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              accept="image/*,.pdf,.zip,.tar.gz"
            />

            <button
              onClick={() => setShowCodeEditor(!showCodeEditor)}
              className={`icon-btn ${showCodeEditor ? 'icon-btn-on' : ''}`}
              title="Enviar código"
            >
              <Code className="w-5 h-5" />
            </button>

            <button onClick={sendScreenshot} className="icon-btn" title="Compartilhar imagem">
              <Image className="w-5 h-5" />
            </button>

            {user.tipo === 'PROFESSOR' && (
              <button
                onClick={() => setShowQuizModal(!showQuizModal)}
                className="icon-btn"
                title="Criar quiz"
              >
                <Trophy className="w-5 h-5 neon-violet" />
              </button>
            )}

            <input
              type="text"
              className="input-field flex-1"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
              placeholder="Digite @Coder para perguntar à IA... (Enter para enviar)"
            />

            <button onClick={sendMessage} className="btn-primary p-2.5">
              <Send className="w-4 h-4" />
            </button>
          </div>

          {/* Quiz Creator Modal */}
          {showQuizModal && user.tipo === 'PROFESSOR' && !activeQuiz && (
            <div className="mt-3 p-4 quiz-panel">
              <h4 className="text-sm font-semibold neon-violet mb-3">Criar Quiz</h4>
              <input
                className="input-field mb-2"
                placeholder="Pergunta..."
                value={quizForm.pergunta}
                onChange={(e) => setQuizForm({ ...quizForm, pergunta: e.target.value })}
              />
              {quizForm.opcoes.map((op, i) => (
                <input
                  type="text"
                  key={i}
                  autoComplete={i === 0 ? "off" : "new-password"} // Ajusta o autocomplete especificamente para a primeira opção
                  className="input-field mb-2"
                  placeholder={`Opção ${i + 1}${i === 0 ? ' (correta)' : ''}`}
                  value={op}
                  onChange={(e) => {
                    const opcoes = [...quizForm.opcoes];
                    opcoes[i] = e.target.value;

                    if (i === 0) {
                      setQuizForm({ ...quizForm, opcoes, respostaCorreta: e.target.value });
                    } else {
                      setQuizForm({ ...quizForm, opcoes });
                    }
                  }}
                />
              ))}
              <div className="flex items-center gap-2 mb-3">
                <label className="text-sm txt-dim">Tempo (seg):</label>
                <input
                  type="number"
                  className="input-field w-20 py-1"
                  value={quizForm.tempoLimite}
                  onChange={(e) => setQuizForm({ ...quizForm, tempoLimite: parseInt(e.target.value) || 30 })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowQuizModal(false)} className="btn-secondary text-sm">
                  Cancelar
                </button>
                <button onClick={createQuiz} className="btn-primary text-sm">
                  Criar Quiz
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;
